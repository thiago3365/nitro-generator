# nitro
This repository is protected by the CC-BY-ND 4.0 License.

Nitrogen is a Discord Nitro Generator that runs solely on HTML and Javascript.

For the generator, go to https://sitesgithub.github.io/nitro/
